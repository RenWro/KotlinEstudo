import android.os.Bundle

import android.view.View

import androidx.appcompat.app.AppCompatActivity

import android.widget.EditText

import android.widget.TextView

class MainActivity : AppCompatActivity() {

lateinit var editText: EditText

lateinit var editText2: EditText

//quando uso o latinit é uma sinalização que a varivel será
inicilizada depoisla

lateinit var textView: TextView

override fun onCreate(savedInstanceState: Bundle?) {

super.onCreate(savedInstanceState)

setContentView(R.layout.activity_main)

editText = findViewById(R.id.editTextCotacao) as EditText

editText2 = findViewById(R.id.editTextQuantidade) as EditText

textView = findViewById(R.id.textViewResultado) as TextView

}

fun converteDolar(view: View){

val cota : Double = editText.text.toString().toDouble()

val qtd : Double = editText2.text.toString().toDouble()

val total : Double = cota * qtd

textView.setText("O Valor em Reais é $total")

}

}